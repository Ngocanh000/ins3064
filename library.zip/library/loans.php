<?php
include "connection.php";
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

// Lấy user_id
$userQuery = mysqli_query($link, "SELECT id FROM users WHERE username='$username'");
$userRow = mysqli_fetch_assoc($userQuery);
$user_id = $userRow['id'];

// LẤY DANH SÁCH SÁCH ĐÃ MƯỢN
$sql = "
    SELECT loans.*, books.title, books.cover_image, books.link
    FROM loans
    JOIN books ON loans.book_id = books.id
    WHERE loans.user_id = $user_id
    ORDER BY loans.borrow_date DESC
";
$result = mysqli_query($link, $sql);

// Nếu lỗi → in ra lỗi luôn để tránh 500
if (!$result) {
    echo "<h3>SQL ERROR:</h3>";
    echo mysqli_error($link);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sách đã mượn</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<div class="container">
    <h2>Sách bạn đã mượn</h2>

    <?php if (mysqli_num_rows($result) == 0): ?>
        <p>Bạn chưa mượn sách nào.</p>
    <?php else: ?>

    <table border="1" cellpadding="10">
        <tr>
            <th>Ảnh</th>
            <th>Tên sách</th>
            <th>Ngày mượn</th>
            <th>Trạng thái</th>
            <th>Đọc sách</th>
            <th>Trả sách</th>
        </tr>

        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><img src="<?= $row['cover_image'] ?>" width="80"></td>
            <td><?= $row['title'] ?></td>
            <td><?= $row['borrow_date'] ?></td>
            <td>
                <?php if ($row['status'] == 'borrowed'): ?>
                    <span style="color:blue;">Đang mượn</span>
                <?php else: ?>
                    <span style="color:green;">Đã trả</span>
                <?php endif; ?>
            </td>

            <td>
                <a href="<?= $row['link'] ?>" target="_blank">Xem</a>
            </td>

            <td>
                <?php if ($row['status'] == 'borrowed'): ?>
                    <a href="return.php?id=<?= $row['id'] ?>">Trả sách</a>
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <?php endif; ?>
</div>
</body>
</html>
