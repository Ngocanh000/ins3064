<?php
session_start();
include "connection.php";

if (!isset($_GET['id'])) exit("Thiếu ID!");

$loan_id = intval($_GET['id']);

// Kiểm tra khoản mượn có tồn tại không
$loan = mysqli_fetch_assoc(mysqli_query($link,
    "SELECT * FROM loans WHERE id = $loan_id"
));
if (!$loan) die("Khoản mượn không tồn tại!");

$book_id = $loan['book_id'];

// Cập nhật trạng thái trả sách
mysqli_query($link, "
    UPDATE loans
    SET status='returned', return_date = NOW()
    WHERE id = $loan_id
");

// Cộng lại số lượng sách
mysqli_query($link, "
    UPDATE books 
    SET quantity = quantity + 1
    WHERE id = $book_id
");

// Quay lại trang cũ
header("Location: loans.php");
exit();
?>
