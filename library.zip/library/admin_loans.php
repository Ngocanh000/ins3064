<?php
session_start();
include "connection.php";

if ($_SESSION['role'] != "admin") {
    die("Không có quyền truy cập!");
}

$loans = mysqli_query($link, "
    SELECT l.*, b.title, u.username
    FROM loans l
    JOIN books b ON l.book_id = b.id
    JOIN users u ON l.user_id = u.id
    ORDER BY l.borrowed_at DESC
");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="style.css">
<title>Quản lý mượn trả</title>
</head>
<body>

<div class="container">
    <h2>📚 Toàn bộ lịch sử mượn sách</h2>
    <a href="home.php">⬅ Về trang Admin</a>
    <br><br>

    <table class="books">
        <tr>
            <th>User</th>
            <th>Tên sách</th>
            <th>Ngày mượn</th>
            <th>Ngày trả</th>
            <th>Trạng thái</th>
            <th>Hành động</th>
        </tr>

        <?php while($row = mysqli_fetch_assoc($loans)): ?>
        <tr>
            <td><?= $row['username'] ?></td>
            <td><?= $row['title'] ?></td>
            <td><?= $row['borrowed_at'] ?></td>
            <td><?= $row['returned_at'] ?: "—" ?></td>
            <td><?= $row['status'] ?></td>
            <td>
                <?php if ($row['status'] == "borrowed"): ?>
                    <a href="return.php?id=<?= $row['id'] ?>">Đánh dấu Trả</a>
                <?php else: ?>
                    —
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>

    </table>
</div>

</body>
</html>
