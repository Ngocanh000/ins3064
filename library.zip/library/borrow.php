<?php
session_start();
include "connection.php";

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Lấy user_id từ username
$u = $_SESSION['username'];
$user = mysqli_fetch_assoc(mysqli_query($link, "SELECT id FROM users WHERE username='$u'"));
$user_id = $user['id'];

$book_id = intval($_GET['id']);

// Check số lượng sách
$b = mysqli_fetch_assoc(mysqli_query($link,
    "SELECT quantity FROM books WHERE id = $book_id"
));

if ($b['quantity'] <= 0) {
    die("Sách đã hết!");
}

// Thêm khoản mượn
mysqli_query($link, "
    INSERT INTO loans (user_id, book_id, status)
    VALUES ($user_id, $book_id, 'borrowed')
");

// Trừ số lượng sách
mysqli_query($link, "
    UPDATE books SET quantity = quantity - 1 WHERE id = $book_id
");

header("Location: loans.php");
exit();
?>
